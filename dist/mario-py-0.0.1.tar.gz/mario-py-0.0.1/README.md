# mario-py
`mario-py` is a Python package for matching and integrating multi-modal single cell data with partially overlapping features.
